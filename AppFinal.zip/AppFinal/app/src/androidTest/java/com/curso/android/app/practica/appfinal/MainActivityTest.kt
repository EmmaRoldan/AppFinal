package com.curso.android.app.practica.appfinal

import androidx.test.espresso.Espresso
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.assertion.ViewAssertions
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest {

    @get:Rule
    var rule: ActivityScenarioRule<*> = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun mainActivity_compareEmptyStrings() {
        Espresso.onView(
            ViewMatchers.withId(R.id.compareButton)
        ).perform(
            ViewActions.click()
        )

        Espresso.onView(
            ViewMatchers.withId(R.id.resultTextView)
        ).check(
            ViewAssertions.matches(
                ViewMatchers.withText("Error: Complete ambos campos.")
            )
        )
    }

    @Test
    fun mainActivity_compareEqualStrings() {
        Espresso.onView(
            ViewMatchers.withId(R.id.editText2)
        ).perform(
            ViewActions.typeText("qwerty")
        )

        Espresso.onView(
            ViewMatchers.withId(R.id.editText2)
        ).perform(
            ViewActions.typeText("qwerty")
        )

        Espresso.onView(
            ViewMatchers.withId(R.id.compareButton)
        ).perform(
            ViewActions.click()
        )

        Espresso.onView(
            ViewMatchers.withId(R.id.resultTextView)
        ).check(
            ViewAssertions.matches(
                ViewMatchers.withText(R.string.app_name)
            )
        ).check(
            ViewAssertions.matches(
                ViewMatchers.hasTextColor(R.color.purple_200)
            )
        )
    }

    @Test
    fun mainActivity_compareDifferentStrings() {
        Espresso.onView(
            ViewMatchers.withId(R.id.editText1)
        ).perform(
            ViewActions.typeText("qwerty")
        )

        Espresso.onView(
            ViewMatchers.withId(R.id.editText2)
        ).perform(
            ViewActions.typeText("dvorak")
        )

        Espresso.onView(
            ViewMatchers.withId(R.id.compareButton)
        ).perform(
            ViewActions.click()
        )

        Espresso.onView(
            ViewMatchers.withId(R.id.resultTextView)
        ).check(
            ViewAssertions.matches(
                ViewMatchers.withText(R.string.app_name)
            )
        ).check(
            ViewAssertions.matches(
                ViewMatchers.hasTextColor(R.color.teal_700)
            )
        )
    }
}