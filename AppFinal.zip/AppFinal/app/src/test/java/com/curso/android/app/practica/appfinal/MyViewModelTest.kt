package com.curso.android.app.practica.appfinal
import org.junit.Before
import org.junit.Test
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse

class MyViewModelTest {

    private lateinit var viewModel: MyViewModel

    @Before
    fun setUp() {
        viewModel = MyViewModel()
    }

    @Test
    fun testCompareStrings_equal() {
        val result = viewModel.compareStrings("Hola", "Hola")
        assertTrue(result)
    }

    @Test
    fun testCompareStrings_notEqual() {
        val result = viewModel.compareStrings("Hola", "Mundo")
        assertFalse(result)
    }
}

