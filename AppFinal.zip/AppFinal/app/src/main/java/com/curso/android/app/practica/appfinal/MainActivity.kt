package com.curso.android.app.practica.appfinal
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.ViewModelProvider
import com.curso.android.app.practica.appfinal.ui.theme.AppFinalTheme


class MainActivity : AppCompatActivity() {
    private var viewModel: MainViewModel? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val editText1: EditText = findViewById(R.id.editText1)
        val editText2: EditText = findViewById(R.id.editText2)
        val compareButton: Button = findViewById(R.id.compareButton)
        val resultTextView: TextView = findViewById(R.id.resultTextView)
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        compareButton.setOnClickListener {
            val str1 = editText1.text.toString()
            val str2 = editText2.text.toString()
            viewModel!!.compareStrings(str1, str2)
        }
        viewModel!!.getAreEqual().observe(this
        ) { areEqual: Boolean? ->
            if (areEqual != null) {
                resultTextView.text =
                    if (areEqual) "Las cadenas son iguales" else "Las cadenas son diferentes"
            }
        }
    }
}


@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    AppFinalTheme {
        Greeting("Android")
    }
}