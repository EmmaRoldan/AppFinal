package com.curso.android.app.practica.appfinal

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel


class MainViewModel : ViewModel() {
    private val areEqual = MutableLiveData<Boolean>()
    fun getAreEqual(): LiveData<Boolean> {
        return areEqual
    }

    fun compareStrings(str1: String, str2: String) {
        val result = str1 == str2
        areEqual.value = result
    }
}

